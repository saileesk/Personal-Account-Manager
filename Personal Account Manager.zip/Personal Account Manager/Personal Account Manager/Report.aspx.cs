﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// this will be used to connect database
using System.Data.SqlClient;

namespace Personal_Account_Manager
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connetionString = null;
            SqlConnection connection  ;
            //SqlCommand command ;
            //string sql = null;
            connetionString = "Data Source=.;Initial Catalog=expense;Integrated Security=True";
            //sql = "Select * from expenses;";
            connection = new SqlConnection(connetionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select * from table_expenses";
                    cmd.Connection = connection;
                    connection.Open();
                    GridView1.DataSource = cmd.ExecuteReader();
                    GridView1.DataBind();
                    connection.Close();
                }

                //connection.Open();
                //command = new SqlCommand(sql, connection);
                //GridView1.DataSource = command.ExecuteReader();
                //GridView1.DataBind();
                //command.Dispose();
                //connection.Close();
            }
            catch (Exception ex)
            {
                string ab;
            }
        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}