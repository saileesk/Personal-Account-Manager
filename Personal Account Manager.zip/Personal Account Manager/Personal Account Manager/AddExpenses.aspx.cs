﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace Personal_Account_Manager
{
    public partial class Report : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // code to grab the value of text box using tb1,tb2.tb3,tb4
            string description = (tb2.Value).ToString();
            string cost = (tb3.Value).ToString();
            string date = (Text1.Value).ToString();
            string tag = (tb4.Value).ToString();

            string connetionString = null;
            SqlConnection connection  ;
            SqlCommand command ;
            string sql = null;
            connetionString = "Data Source=.;Initial Catalog=expense;Integrated Security=True";

            //sql = "INSERT INTO [dbo].[expenses] ([description], [cost], [date], [tag]) VALUES (' " + tb1 + "'," + tb2 + ", '" + tb3 + "', '" + tb4 + "')";
            
            connection = new SqlConnection(connetionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "INSERT INTO [dbo].[table_expenses] ([description], [cost], [date], [tag]) VALUES ('" + description + "','" + cost + "','" + date + "','" + tag + "')";
                    cmd.Connection = connection;
                    connection.Open();
                    cmd.ExecuteReader();
                    connection.Close();
                }

            }
            catch (Exception ex)
            {
                string ab;
            }
        }
        }
    }